# Two notions of tightness for the flat overhand knot

[Read the paper (PDF)](paper/main.pdf) · [Reproduce the results](REPRODUCE.md) · [Cite the manuscript](CITATION.cff)

An overhand knot folded flat in a strip has two ways to measure tightness. On the three-crease branch with layer order **B > D > A > C**, the regular pentagon strictly minimizes truncation length locally. The notched state θ† uniquely minimizes core length throughout the width-one positive working chart. Every slack valid state in this chart admits at least one pulling path to θ† that preserves the branch and never increases core length.

[![Four folded ribbon panels form a seven-sided outline. The inset enlarges the V-shaped notch on its left edge.](paper/figs/theta-dagger-heptagon.svg)](paper/figs/theta-dagger-heptagon.svg)

**Figure 6 from the paper.** The notch lies on the mirror axis of θ†. Its mouth is about 0.0845 strip widths across. Compare the [regular pentagon in Figure 2](paper/figs/fig1-pentagon.svg) and the [two core-length curves in Figure 4](paper/figs/fig4-two-families.svg).

## Run the certificates

```sh
uv sync --locked
sh scripts/verify-core.sh
```

A successful run ends with `PASS: core certificates, mutation controls and figure checks`. The [reproducibility guide](REPRODUCE.md) gives the inputs, methods and expected results for Theorems A–H, along with commands for the longer numerical searches.

## Results and scope

| Result | Evidence |
|---|---|
| The three-crease trefoil has crossing word `XYZXYZ`, alternating crossings and slope signs unique up to mirror. A compatible global order is uniquely B > D > A > C. Loose configurations can realize cyclic local orders. | Combinatorial enumeration, an explicit realization, and a common four-panel overlap near the two optima and along the standard slice and second family. |
| Kauffman's pentagon is a strict local minimum of truncation length. Core length has a feasible descent direction there. | Exact Farkas certificate for truncation and an eight-wall descent certificate for core length. |
| θ† is the unique global minimum of core length in this chart, with equality only at θ†. Its coordinate field has degree 12 and the associated sextic has Galois group S₆. | Four necessary contact inequalities, strict averaging and an exact polynomial bound. The equality case agrees with the degree-12 state. |
| Every slack start in the positive chart can reach θ†. The constructed path first keeps core length fixed and then decreases it strictly. | Exact panel and crossing identities, finite-step inequalities and separate isolation of the algebraic endpoint. |
| Every valid trefoil state in this chart admits a limit realization in shrinking slabs. Positive clearance gives a strong realization at every sufficiently small prescribed slab height. | A fixed-angle dilation opens all four forbidden crease–panel gaps and separates the two distant creases. |
| The figure-eight state has core length 4√15/3 and truncation length 32√15/15. | The eight contact inequalities characterize actual panel nonpenetration near the hexagon. Exact cap geometry and positive KKT multipliers prove strict local minimality of core length in the specified geometric cell. |

The model uses zero-thickness ribbons and movable complete creases. It remains open whether a higher-length state can block all first-order descent directions. Convergence of a given descent procedure, comparisons across branches and lifting an entire pulling path into a slab of fixed height are separate questions. The [Lean project](formal/README.md) proves 16 supporting algebraic statements.

## Materials

| Path | Contents |
|---|---|
| [paper](paper/) | LaTeX manuscript, compiled PDF and figures |
| [verify](verify/) | Exact certificates, interval checks and numerical experiments |
| [Recorded figure-eight search](verify/artifacts/n4-rerun-20261023/) | Inputs, source snapshots, checkpoints and per-stage results |
| [logs](logs/) | Recorded output and SHA-256 manifests |
| [Ancillary archive](https://github.com/yongsk0066/flat-overhand-knot/raw/refs/heads/main/ancillary.tar.gz) | Current public distribution including the manuscript PDF |

## Citation and license

Yongseok Jang is the author. The full manuscript citation is in [CITATION.cff](CITATION.cff). Code is distributed under the [MIT license](LICENSE). The paper and figures are © 2026 Yongseok Jang, [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
